package fpt.tamttt3.day5;

import java.util.Date;

public class StudentNew {
	private String idStud;
	private String fullName;
	private Date dateOfBirth;
	private String address;
	
	public StudentNew(){
		
	}
	
	/**
	 * @param idStud
	 * @param fullName
	 * @param dateOfBirth
	 * @param address
	 */
	public StudentNew(String idStud, String fullName, Date dateOfBirth,
			String address) {
		super();
		this.idStud = idStud;
		this.fullName = fullName;
		this.dateOfBirth = dateOfBirth;
		this.address = address;
	}


	/**
	 * @return the idStud
	 */
	public String getIdStud() {
		return idStud;
	}
	/**
	 * @param idStud the idStud to set
	 */
	public void setIdStud(String idStud) {
		this.idStud = idStud;
	}
	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return fullName;
	}
	/**
	 * @param fullName the fullName to set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	/**
	 * @return the dateOfBirth
	 */
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	/**
	 * @param dateOfBirth the dateOfBirth to set
	 */
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	
	

}
