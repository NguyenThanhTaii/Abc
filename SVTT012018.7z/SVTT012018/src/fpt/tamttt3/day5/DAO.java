package fpt.tamttt3.day5;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import com.tamttt3.day5.Student;

public class DAO {
	Connection sqlConnect = null;
	Statement stmt = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	ArrayList<StudentNew> ds;
	CallableStatement callstmt = null;
	
	public DAO(){
		ds = new ArrayList<StudentNew>();
	}

	public Connection getConnect() {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			sqlConnect = DriverManager
					.getConnection("jdbc:sqlserver://CPP00082816A\\"
							+ "TAMTTT3:1433;databaseName=StudentDB; username=sd;"
							+ " password=Hoaphuc123@");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return sqlConnect;
	}

	public void addNewStud(StudentNew stud) {
		SimpleDateFormat dateStud = new SimpleDateFormat("yyyy-MM-dd");
		String sqlDateStud = dateStud.format(stud.getDateOfBirth());
		java.sql.Date dStud = java.sql.Date.valueOf(sqlDateStud);
		
		String sqlAddNew = "insert into Student values('" + stud.getIdStud()
				+ "','" + stud.getFullName() + "','" + dStud + "','"
				+ stud.getAddress() + "')";
		try {
			stmt = getConnect().createStatement();
			stmt.executeUpdate(sqlAddNew);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList<StudentNew> listStud(String diachi) {
		try {
			
			pstmt = getConnect().prepareStatement("select IdStud, FullName, Address from Student where Address = ?");
			pstmt.setString(1, diachi);
			rs = pstmt.executeQuery();
			StudentNew stud;
			while (rs.next()) {
				stud = new StudentNew();
				stud.setIdStud(rs.getString("IdStud"));
				stud.setFullName(rs.getString("FullName"));
				stud.setAddress(rs.getString("Address"));
				ds.add(stud);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ds;
		
	}

	public ArrayList<StudentNew> getStud(String diachi) {
		try {
			callstmt = getConnect().prepareCall("{call sp_getStud(?)}");
			rs = callstmt.executeQuery();
			StudentNew stud;
			while (rs.next()) {
				stud = new StudentNew();
				stud.setIdStud(rs.getString("IdStud"));
				stud.setFullName(rs.getString("FullName"));
				stud.setAddress(rs.getString("Address"));
				ds.add(stud);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ds;
	}
	
	public void addNewStudendUseRs(Student stud) {
		try {
			getConnect().setAutoCommit(false);
			stmt = getConnect().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			rs = stmt.executeQuery("Select IdStud, FullName, Age from Student");
			rs.moveToInsertRow();
			
			//add data
			rs.updateString("IdStud", stud.getIdStud());
			rs.updateString("FullName", stud.getFullName());
			
			//convertion from Util date to sql date for Date of Birth
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			String stringDate= dateFormat.format(stud.getDateOfBirth());
			java.sql.Date sqlDate=  java.sql.Date.valueOf(stringDate);
			
			rs.updateDate("DateOfBirth", sqlDate);
			rs.updateString("Address", stud.getAddress());
	
			
			// Commit row
			rs.insertRow();
			getConnect().commit();
			getConnect().setAutoCommit(true);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			getConnect().rollback();
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		DAO db = new DAO();
		Scanner input = new Scanner(System.in);
		// nhap thong tin sinh vien
		/*System.out.println("Ma sinh vien");
		String maSV = input.nextLine();
		System.out.println("Ho ten sinh vien");
		String hoTen = input.nextLine();
		System.out.println("Nhap ngay sinh");
		String ngaySinh = input.nextLine();
		Date ns = new Date(ngaySinh);*/
		System.out.println("Nhap dia chi");
		String diaChi = input.nextLine();

		//StudentNew st1 = new StudentNew(maSV, hoTen, ns, diaChi);
		// add vao db
		//db.addNewStud(st1);
		//hien thi danh sach theo dia chi
		ArrayList<StudentNew> dsSinhVien = db.listStud(diaChi);
		for (StudentNew item : dsSinhVien) {
			System.out.println(item.getIdStud()+","+item.getFullName());
		}
	}

}
