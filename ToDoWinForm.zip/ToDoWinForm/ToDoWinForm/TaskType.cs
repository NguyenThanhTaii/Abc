﻿namespace ToDoWinForm
{
    enum TaskType
    {
        BackLog,
        Resolved,
        Closed
    }
}