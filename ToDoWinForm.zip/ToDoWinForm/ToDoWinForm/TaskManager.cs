﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ToDoWinForm
{
    public class TaskManager
    {
        public List<Task> ListTasks { get; set; }

        public TaskManager()
        {
            ListTasks = new List<Task>();
            InitListTasks();
        }

        public void AddTask(Task task)
        {
            task.Id = ListTasks.Count > 0 ? ListTasks.Max(x => x.Id) + 1 : 1;
            task.Type = (int)TaskType.BackLog;
            ListTasks.Add(task);
        }

        public void UpdateTask(string name, int id)
        {
            var task = ListTasks.FirstOrDefault(x => x.Id == id);
            switch (name)
            {
                case "lbBacklog":
                    task.Type = (int)TaskType.BackLog;
                    break;
                case "lbResolved":
                    task.Type = (int)TaskType.Resolved;
                    break;
                case "lbClosed":
                    task.Type = (int)TaskType.Closed;
                    break;
            }
        }

        public void InitListTasks()
        {
            ListTasks.Add(new Task
            {
                Id = 1,
                Title = "Review Plan Tracker's",
                StartDate = new DateTime(2017, 3, 15),
                FinishDate = new DateTime(2017, 3, 20),
                Type = (int)TaskType.BackLog
            });
            ListTasks.Add(new Task
            {
                Id = 2,
                Title = "Review Database",
                StartDate = new DateTime(2017, 3, 15),
                FinishDate = new DateTime(2017, 3, 20),
                Type = (int)TaskType.Resolved
            });
            ListTasks.Add(new Task
            {
                Id = 3,
                Title = "Report Project Status",
                StartDate = new DateTime(2017, 3, 15),
                FinishDate = new DateTime(2017, 3, 20),
                Type = (int)TaskType.Closed
            });
        }
    }
}
