﻿using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace ToDoWinForm
{
    public partial class frmTodo : Form
    {
        private TaskManager _taskManager; 

        public frmTodo()
        {
            InitializeComponent();

            _taskManager = new TaskManager();

            InitListBox();
        }

        private void btnAdd_Click(object sender, System.EventArgs e)
        {
            if (string.IsNullOrEmpty(txtTitle.Text))
            {
                MessageBox.Show("Title is required!");
            }
			else if (dpkFinishDate.Value.Date < dpkStartDate.Value.Date)
            {
                MessageBox.Show("Finish Date cannot be earlier than Start Date");
            }
            else
            {
                var task = new Task
                {
                    Title = txtTitle.Text,
                    Description = txtDescription.Text,
                    StartDate = dpkStartDate.Value.Date,
                    FinishDate = dpkFinishDate.Value.Date
                };
                _taskManager.AddTask(task);
                lbBacklog.Items.Add(task);
                ClearTextBox();
            }
        }

        private void MouseDownHandle(object sender, MouseEventArgs e)
        {
            var listbox = (ListBox)sender;
            if (listbox.Items.Count == 0)
                return;

            int index = listbox.IndexFromPoint(e.X, e.Y);
            if (index != -1)
            {
                var task = (Task)listbox.Items[index];
                var dde = DoDragDrop(task, DragDropEffects.All);
                if (dde == DragDropEffects.All)
                {
                    listbox.Items.RemoveAt(listbox.IndexFromPoint(e.X, e.Y));
                }
            }
        }

        private void DragDropHandle(object sender,DragEventArgs e)
        {
            var listbox = (ListBox)sender;
            var task = (Task)e.Data.GetData(typeof(Task));

            _taskManager.UpdateTask(listbox.Name, task.Id);
            listbox.Items.Add(task);
        }

        private void DragOverHandle(object sender,DragEventArgs e)
        {
            e.Effect = DragDropEffects.All;
        }

        private void ClearTextBox()
        {
            txtTitle.Text = "";
            txtDescription.Text = ""; 
        }

        private void InitListBox()
        {
            lbBacklog.DisplayMember = "Title";
            lbBacklog.ValueMember = "Id";
            lbResolved.DisplayMember = "Title";
            lbResolved.ValueMember = "Id";
            lbClosed.DisplayMember = "Title";
            lbClosed.ValueMember = "Id";

            lbBacklog.Items.AddRange(_taskManager.ListTasks.Where(x => x.Type == (int)TaskType.BackLog).ToArray());
            lbResolved.Items.AddRange(_taskManager.ListTasks.Where(x => x.Type == (int)TaskType.Resolved).ToArray());
            lbClosed.Items.AddRange(_taskManager.ListTasks.Where(x => x.Type == (int)TaskType.Closed).ToArray());
        }
    }
}
